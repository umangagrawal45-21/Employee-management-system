import { Component, OnInit } from '@angular/core';
import { Employee } from './employee.model';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  employees: Employee[] = [];
  model: Employee = { name: '', dept: '', salary: 0, age: 0 };
  message = '';
  isError = false;

  constructor(private service: EmployeeService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.service.getAllEmployee().subscribe({
      next: data => this.employees = data,
      error: () => this.show('Could not load employees. Is the backend running on port 9008?', true)
    });
  }

  save(): void {
    if (!this.model.name.trim() || !this.model.dept.trim() || this.model.salary <= 0 || this.model.age <= 0) {
      this.show('Please fill all fields with valid values.', true);
      return;
    }
    this.service.addEmployee(this.model).subscribe({
      next: () => {
        this.show('Employee added successfully.', false);
        this.model = { name: '', dept: '', salary: 0, age: 0 };
        this.load();
      },
      error: () => this.show('Failed to add employee.', true)
    });
  }

  private show(msg: string, err: boolean): void { this.message = msg; this.isError = err; }
}
