# Employee Management System (Angular 17 + Spring Boot)

Backend (port 9008): POST /addEmployee, GET /getAllEmployee
Database: MySQL `bmsdb`, table `emp2` (created by Hibernate ddl-auto=update).
Update and Delete are NOT implemented.

## Run
1. Create the database: `CREATE DATABASE bmsdb;`
2. Put your MySQL password in backend/src/main/resources/application.properties
3. Backend: `cd backend && mvn spring-boot:run`
4. Frontend: `cd frontend && npm install && npx ng serve`, then open http://localhost:4200

Note: this code was written as a starting point and has not been run by its author tool. Run it and record your own test results.
