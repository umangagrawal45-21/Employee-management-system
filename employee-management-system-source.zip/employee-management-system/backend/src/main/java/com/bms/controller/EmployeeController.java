package com.bms.controller;

import com.bms.model.Employee;
import com.bms.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin
public class EmployeeController {
    @Autowired
    private EmployeeService service;

    @PostMapping("/addEmployee")
    public Employee addEmployee(@RequestBody Employee e) { return service.addEmployee(e); }

    @GetMapping("/getAllEmployee")
    public List<Employee> getAllEmployee() { return service.getAllEmployee(); }
}
