package com.bms.service;

import com.bms.model.Employee;
import com.bms.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository repo;

    public Employee addEmployee(Employee e) { return repo.save(e); }
    public List<Employee> getAllEmployee() { return repo.findAll(); }
}
